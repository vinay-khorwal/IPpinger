let timer; // Variable to hold the timeout reference

// Define the pingIP function
async function pingIP() {
    const ipInput = document.getElementById('ipInput');
    const output = document.getElementById('output');
    const ip = ipInput.value;

    if (!ip) {
        output.textContent = 'Please enter an IP address.';
        return;
    }

    output.textContent = 'Pinging...';

    try {
        const response = await fetch('/ping/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ ip: ip })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            output.textContent = 'Ping successful: ' + result.output;
        } else {
            output.textContent = 'Ping failed: ' + result.output;
        }
    } catch (error) {
        output.textContent = 'Error: ' + error.message;
    }
}

// Function to start the ping process
function startPing() {
    const button = document.getElementById('autoClickButton');
    console.log('Selected button:', button);

    if (button) {
        console.log('Button found, setting up auto-click timer');
        const timer = setTimeout(() => {
            console.log('Attempting to auto-click the button');
            // button.click();
            pingIP();
            console.log('Button clicked');
        }, 2000);
    } else {
        console.error('Button not found');
    }
}

// Function to stop the ping process
function stopPing() {
    if (timer) {
        clearTimeout(timer); // Cancel the pending click
        timer = null; // Reset the timer variable
        console.log('Ping process stopped');
    }
}

// Wait for the DOM to load
document.addEventListener('DOMContentLoaded', () => {
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');

    // Attach event listeners to the buttons
    startButton.addEventListener('click', startPing);
    stopButton.addEventListener('click', stopPing);
});