from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import subprocess
from .models import *
import requests

@csrf_exempt
def add_ip(request):
    print("add_ip method is called")
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ip = data.get('ip')

            if not history.objects.filter(ip=ip).exists():
                new_ip = history(ip=ip)  # Create new history entry
                new_ip.save()
            

            if not active_ip.objects.filter(active_ip=ip).exists():
                new_active_ip = active_ip(active_ip=ip)  # Create new active_ip entry
                new_active_ip.save()
            
            return JsonResponse({'success': True, 'message': 'IP added successfully.'})
            
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON.'}, status=400)
        except Exception as e:
            print(e)  # Log the error for debugging
            return JsonResponse({'error': 'Internal server error'}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method.'}, status=405)

    

@csrf_exempt
def delete_ip(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ip = data.get('ip')

            if active_ip.objects.filter(active_ip=ip).exists():
                active_ip.objects.filter(active_ip=ip).delete()
                return JsonResponse({'success': True, 'message': 'IP deleted successfully.'})
            else:
                return JsonResponse({'success': False, 'message': 'IP not found.'})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON.'}, status=400)
        except Exception as e:
            print(e)  # Log the error for debugging
            return JsonResponse({'error': 'Internal server error'}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method.'}, status=405)


@csrf_exempt
def ping_view(request):
    print("ping_view method called")
    if request.method == 'POST':
        try:
            output = startTimer()
            print(output)
            return JsonResponse({'success': True, 'output': output})
        except Exception as e:
            print(e)
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method.'}, status=405)


def startTimer():
    IPs = active_ip.objects.all()
    results = dict()
    for i in IPs:
        try:
            # output = subprocess.check_output(['ping', '-n', '1', i.active_ip], universal_newlines=True)
            command_avg_time = f'for /f "tokens=9" %a in (\'ping -n 1 {i.active_ip} ^| findstr /i "average"\') do @echo %a'
            avg_time = subprocess.check_output(command_avg_time, universal_newlines=True, shell=True)

            command_pkt_loss = f'for /f "tokens=10 delims=, " %a in (\'ping {i.active_ip} -n 1 ^| findstr /i "Lost"\') do @echo %a'
            pkt_loss = subprocess.check_output(command_pkt_loss, universal_newlines=True, shell=True)

            r = requests.get(f'https://api.iplocation.net/?ip={i.active_ip}', auth=('user', 'pass'))
            location_data = r.json()

            if r.status_code == 200:
                location_data = r.json()
                # print(f"Raw location data for {i.active_ip}: {location_data}")

                # Extract country name and ISP from the location data
                country_name = location_data.get('country_name', 'Unknown')
                isp = location_data.get('isp', 'Unknown')
            else:
                # print(f"Failed to get location for {i.active_ip}: {r.status_code} {r.text}")
                country_name = 'Unknown'
                isp = 'Unknown'

            # print(f'Average time: {avg_time.strip()}')
            results[i.active_ip] = [avg_time, pkt_loss, country_name, isp]
            # print(output)
            # results[i.active_ip] = output
        except subprocess.CalledProcessError:
            # print(i.active_ip, "ping unsuccessful")
            results[i.active_ip] = "ping unsuccessful"
    return results


@csrf_exempt
def fetch_history(request):
    if request.method == 'GET':
        pre_ips = history.objects.all()
        ip_list = [record.ip for record in pre_ips]
        return JsonResponse({'pre_ips': ip_list})
    return JsonResponse({'error': 'Invalid request method.'}, status=405)

def index(request):
    pre_ips = history.objects.all()
    content = {'pre_ips':pre_ips}
    return render(request, 'index.html', content)

