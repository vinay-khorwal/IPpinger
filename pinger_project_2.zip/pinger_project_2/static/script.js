

async function fetchHistory() {
    try {
        const response = await fetch('/fetch_history/');
        const data = await response.json();

        const historyList = document.getElementById('history-list');
        historyList.innerHTML = ''; // Clear the previous history

        data.pre_ips.forEach(ip => {
            const div = document.createElement('div');
            const span = document.createElement('span');
            div.className = 'history-item';
            // span.className = 'span-history-item';
            span.textContent = ip;
            div.appendChild(span);
            historyList.appendChild(div);

            div.addEventListener('click', () => {
                const ipInput = document.getElementById('IPaddress');
                ipInput.value = ip;
            });

        });

        
    } catch (error) {
        console.error('Error fetching history:', error);
    }
}


async function newIP(){
    const ipInput = document.getElementById('IPaddress');
    const ip = ipInput.value;

    if(!ip){
        alert("Please enter an IP address.");
    }else{
        const csrftoken = getCookie('csrftoken'); // Use getCookie function to get CSRF token
        console.log(`Sending IP: ${ip}`);
        const response = await fetch('addip/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrftoken, // Include CSRF token in headers
                },
                body: JSON.stringify({ ip: ip })
            });

        const result = await response.json();
        console.log(`Received response from newIP: ${JSON.stringify(result)}`);

        if (response.ok && result.success) {
            console.log('IP added successfully.');
            await fetchHistory();
        } else {
            console.error('Failed to add IP:', result.message);
        }
    }
}

async function deleteIP(ip) {
    const csrftoken = getCookie('csrftoken'); // Use getCookie function to get CSRF token
    try {
        const response = await fetch('deleteip/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken, // Include CSRF token in headers
            },
            body: JSON.stringify({ ip: ip })
        });

        const result = await response.json();
        console.log(`Received response from deleteIP: ${JSON.stringify(result)}`);

        if (response.ok && result.success) {
            console.log('IP deleted successfully.');
            // Refresh the ping results after deletion
            IPping();
        } else {
            console.error('Failed to delete IP:', result.message);
        }
    } catch (error) {
        console.error('An error occurred while deleting IP:', error.message);
    }
}

async function status_report(res){
    if(res!=='ping unsuccessful'){
        return 'active';
    }else{
        return 'inactive';
    }
}


async function IPping() {
    console.log("IPping function is called");
    const output = document.getElementById('output');
    
    try {
        const csrftoken = getCookie('csrftoken'); // Use getCookie function to get CSRF token
        const response = await fetch('ping/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken, // Include CSRF token in headers
            },
        });

        const result = await response.json();
        console.log(`Received response: ${JSON.stringify(result)}`);

        if (response.ok && result.success) {
            output.innerHTML = ''; // Clear the previous output

            for (const [ip, res] of Object.entries(result.output)) {
                const row = document.createElement('div');
                row.className = 'output-row';

                const ipCell = document.createElement('div');
                ipCell.className = 'output-cell';
                ipCell.textContent = ip;

                const activeCell = document.createElement('div');
                activeCell.className = 'output-cell active-cell';
                activeCell.textContent = await status_report(res);

                const resCell = document.createElement('div');
                resCell.className = 'output-cell';
                if(res !== 'ping unsuccessful'){
                    resCell.innerHTML = 'Avg time: ' + res[0] + '<br>' + 
                    'Loss: ' + res[1] + '%' + '<br>' + 
                    'Location: ' + res[2] + '<br>' + 
                    'ISP: ' + res[3];
                }else{
                    resCell.textContent = 'ping unsuccessful';
                }



                const deleteButton = document.createElement('button');
                deleteButton.className = 'delete-button';
                deleteButton.textContent = 'Delete';
                deleteButton.onclick = () => deleteIP(ip);


                row.appendChild(ipCell);
                row.appendChild(activeCell);
                row.appendChild(resCell);
                row.appendChild(deleteButton);
                output.appendChild(row);

                // Set background color based on status
                activeCell.style.backgroundColor = (await status_report(res)) === 'active' ? 'rgb(102, 228, 102)' : 'rgb(238, 111, 111)';


            }
        } else {
            output.textContent = 'Ping failed or No active IP ' + JSON.stringify(result.output);
        }
    } catch (error) {
        output.textContent = 'An error occurred: ' + error.message;
        console.error(error);
    }
}


document.addEventListener('DOMContentLoaded', function() {
    console.log('Document is ready');


    const startButton = document.getElementById('startButton');
    const goButton = document.getElementById('GoButton');
    const stopButton = document.getElementById('stopButton');

    if (startButton) {
        const status = document.getElementById('running-status');
        startButton.addEventListener('click', () => {
            console.log('StartButton clicked');
            clearInterval(window.pingInterval); // Clear any existing intervals
            window.pingInterval = setInterval(IPping, 5000);
            status.textContent = 'Running';
        });
    } else {
        console.error('StartButton not found');
    }

    if (goButton) {
        const status = document.getElementById('running-status');
        goButton.addEventListener('click', () => {
            const ipInput = document.getElementById('IPaddress');
            const ip = ipInput.value;
            console.log('GoButton clicked');
            clearInterval(window.pingInterval);
            if(!ip){
                alert("Please enter an IP address.");
            }else{
                newIP().then(() => {
                    // fetchHistory();
                    window.pingInterval = setInterval(IPping, 5000);
                    status.textContent = 'Running';
                });
            }
            
        });
    } else {
        console.error('GoButton not found');
    }

    if (stopButton) {
        const status = document.getElementById('running-status');
        stopButton.addEventListener('click', () => {
            status.textContent = 'Stopped';
            console.log('StopButton clicked');
            clearInterval(window.pingInterval);
        });
    } else {
        console.error('StopButton not found');
    }

    fetchHistory();

});
