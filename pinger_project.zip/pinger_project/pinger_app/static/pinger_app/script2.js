document.addEventListener('DOMContentLoaded', () => {
    let intervalId;

    async function pingIP() {
        console.log('Function is called');
        const ipInput = document.getElementById('ipInput');
        const ip = ipInput.value;
        const output = document.getElementById('output');

        if (!ip) {
            output.textContent = 'Please enter an IP address.';
            stopFunction();
            return;
        }

        output.textContent = 'Pinging...';

        $.ajax({
            url: '/ping/',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ ip: ip }),
            success: function (result) {
                if (result.success) {
                    output.textContent = 'Ping successful: ' + result.output;
                    updateGraph(parseInt(result.avg_value));
                } else {
                    output.textContent = 'Ping failed: ' + result.output;
                    stopFunction();
                }
            },
            error: function (xhr, status, error) {
                output.textContent = 'Error: ' + error;
                stopFunction();
            }
        });
    }

    function startFunction() {
        if (!intervalId) {
            intervalId = setInterval(pingIP, 3000);
            console.log('Started calling the function');
        }
    }

    function stopFunction() {
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
            console.log('Stopped calling the function');
        }
    }

    document.getElementById('startButton').addEventListener('click', startFunction);
    document.getElementById('stopButton').addEventListener('click', stopFunction);

    const ctx = document.getElementById('myChart').getContext('2d');
    const data = {
        labels: ['time'],
        datasets: [{
            label: 'Ping Data',
            data: [0],
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
            pointRadius: 5,
            pointHoverRadius: 10,
        }]
    };

    const config = {
        type: 'line',
        data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    enabled: true,
                    callbacks: {
                        label: function(context) {
                            return `Ping: ${context.raw}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true
                },
                y: {
                    beginAtZero: true
                }
            },
            onClick: (event, elements) => {
                if (elements.length > 0) {
                    const firstElement = elements[0];
                    const index = firstElement.index;
                    const label = data.labels[index];
                    const value = data.datasets[0].data[index];

                    alert(`You clicked on ${label}: ${value}`);
                }
            }
        }
    };

    const myChart = new Chart(ctx, config);

    function updateGraph(avg_value) {
        const now = new Date();
        const timeString = now.toTimeString().split(' ')[0];
        data.labels.push(timeString);
        data.datasets[0].data.push(avg_value);
        myChart.update();
    }

    function updateClock() {
        const clockElement = document.getElementById('clock');
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const timeString = `${hours}:${minutes}:${seconds}`;
        clockElement.textContent = timeString;
    }

    updateClock();
    setInterval(updateClock, 1000);
});
