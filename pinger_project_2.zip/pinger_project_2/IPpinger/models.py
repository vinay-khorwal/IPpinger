from django.db import models

# Create your models here.

class history(models.Model):
    ip=models.CharField(null=False, blank=False,unique=True, max_length=39)

class active_ip(models.Model):
    active_ip=models.CharField(null=False, blank=False,unique=True, max_length=39)
