from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import json
import subprocess
from django.core.management.base import BaseCommand
import os


@csrf_exempt  # Disable CSRF for simplicity, but handle it properly in production.
def ping_view(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ip = data.get('ip')
            
            if not ip:
                return JsonResponse({'error': 'No IP address provided.'}, status=400)
            
            try:
                output = subprocess.check_output(['ping', '-n', '1', ip], universal_newlines=True)
                print(output)
                command = f'for /f "tokens=9" %a in (\'ping -n 1 {ip} ^| findstr /i "average"\') do @echo %a'

                avg_value = subprocess.check_output(command, universal_newlines=True, shell=True)
                # try:
                #     avg_value = subprocess.check_output(command, universal_newlines=True, shell=True)
                #     print(f'Average time: {avg_value.strip()} ms')
                # except subprocess.CalledProcessError as e:
                #     print(f"Error executing command: {e}")
                print(avg_value)
                return JsonResponse({'success': True, 'output': output, 'avg_value': avg_value})
            except subprocess.CalledProcessError:
                return JsonResponse({'success': False, 'output': 'Ping failed.'})
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON.'}, status=400)
    else:
        return JsonResponse({'error': 'Invalid request method.'}, status=405)


def index(request):
    return render(request, 'pinger_app/index.html')